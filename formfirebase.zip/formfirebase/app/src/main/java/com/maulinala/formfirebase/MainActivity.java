package com.maulinala.formfirebase;

import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button buttonRegistrasi;
    private EditText editTextEmail, editTextPassword;
    private TextView textView;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        buttonRegistrasi = findViewById(R.id.buttonRegistrasi);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        textView = findViewById(R.id.textView);
        textView.setOnClickListener(this);
        buttonRegistrasi.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if (view == buttonRegistrasi){
            registerUser();
        }
        if (view == textView){
            //untuk masuk jika sudah register
        }
    }

    private void registerUser() {
        String Email = editTextEmail.getText().toString().trim();
        String Password = editTextPassword.getText().toString().trim();

        if (TextUtils.isEmpty(Email)){
            Toast.makeText(getApplicationContext(), "Masukan email anda", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(Password)){
            Toast.makeText(getApplicationContext(), "Masukan password anda", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog.setMessage("Registrasi");
        progressDialog.show();

        firebaseAuth.createUserWithEmailAndPassword(Email, Password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Registrasi Berhasil", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Registrasi Gagal, coba lagi", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
